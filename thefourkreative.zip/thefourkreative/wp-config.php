<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'thefourkreative');

/** MySQL database username */
define('DB_USER', 'root');

/** MySQL database password */
define('DB_PASSWORD', '');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8mb4');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         'uxaTX|42BPHNW5N#[qxkKXv_`*W0Y)U%0eoV?lI#;M&C3c8jQqW0}mh(]T9x_y,m');
define('SECURE_AUTH_KEY',  '}sQP}W%~ UZyp)KX,A:Jh]dH)F,tGUA0xC8y~*4~mcf5+:IO0W>Vz1[6q+;lwE=#');
define('LOGGED_IN_KEY',    'F7+U`|VVi!q#~eZ[ EGCd;;?hORh%@NDd:y!4RZkr< k}}pYGLBXOSg`vBT/hI1U');
define('NONCE_KEY',        'owr5pc+^nLd:#/KN80Z3$?PeTwKI0zdHaq,iB{8*i{gOuX0Gni~;5sHwZv^8o!ML');
define('AUTH_SALT',        '|Kc`B,=i:BU9sIpj(bZSrr%G])+6c.L6k<g8Wcb=l_gc|*:WOBt~MqJ,6f$uYKs%');
define('SECURE_AUTH_SALT', '8W5{SnGLq|6dh+5.W[F{,[]GOIflWUjW?AJ[W!VKy/0;klR+,jE[R;nx>cUFbF?m');
define('LOGGED_IN_SALT',   '`bW-t}1Q9+Kb9MdBXS{{FEPW%7d4?[:I3w:ptRmmeC],_7@.J!S$%F8Pq:}U(/R]');
define('NONCE_SALT',       '8$=~oTx@a6OtT<5vY !C3CU`(Cp P(k`V9H>5=01(m5HxND K2RWr4KIu%Tz{C]S');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'tfk_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
